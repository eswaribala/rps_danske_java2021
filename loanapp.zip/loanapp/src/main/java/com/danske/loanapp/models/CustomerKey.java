package com.danske.loanapp.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class CustomerKey implements Serializable{

	@Column(name="Customer_Id")
	private long customerId;
	@Column(name="Account_No")
	private long accountNo;
	
	
}
