package com.danske.loanapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.danske.loanapp.models.Customer;
import com.danske.loanapp.models.CustomerKey;
import com.danske.loanapp.models.Loan;
import com.danske.loanapp.repositories.CustomerRepository;

@Service
public class CustomerService {
	
	//DI
	@Autowired
	private CustomerRepository customerRepository;

	//save
	public Customer addCustomer(Customer customer)
	{
		for(Loan loan : customer.getLoans())
		{
			loan.setCustomer(customer);
		}
		
		return customerRepository.save(customer);
		
	}
	
	//find all
	
	public List<Customer> getAllCustomers()
	{
		return customerRepository.findAll();
	}
	
	
	//findone
	public Customer getCustomerByKey(CustomerKey customerKey)
	{
		return customerRepository.findById(customerKey).orElse(null);
	}
	
	//delete
	
	public boolean deleteCustomerByKey(CustomerKey customerKey)
	{
		boolean status=false;
		customerRepository.deleteById(customerKey);
		if(getCustomerByKey(customerKey)==null)
			status=true;
		return status;
		
	}
	
	
	//update
	public Customer updateCustomer(Customer customer)
	{
		return customerRepository.save(customer);
	}
	
	
	
	
}
