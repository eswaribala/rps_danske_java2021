package com.danske.banking.models;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="Danske_Loan")
public class Loan {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Loan_No")
     private long loanNo;
	@Column(name="Loan_Type",nullable =false,length = 100)
     private String loanType;
	@Column(name="Amount")
     private long amount;
	@Column(name="ROI")
     private float roi;
	@Column(name="Tenure")
     private int tenure;
	@Temporal(value=TemporalType.DATE)
	@Column(name="Issue_Date")
	 private Date issueDate;
	//relationship
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "Customer_Id",nullable = false)
	private Customer customer;
}
