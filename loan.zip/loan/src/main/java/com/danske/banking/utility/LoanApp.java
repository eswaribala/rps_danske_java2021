package com.danske.banking.utility;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.danske.banking.dao.CustomerDao;
import com.danske.banking.dao.CustomerImpl;
import com.danske.banking.models.Customer;
import com.danske.banking.models.Loan;

public class LoanApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        CustomerDao customerDao=new CustomerImpl();
        /*
        Customer customer=new Customer(0,"Bala",new Date(65, 3, 7),8056050425L,null);
      
        Loan loan=new Loan(0,"Home",2500000L,0.9f,52,new Date(113, 11, 1),null);
        loan.setCustomer(customer);
        List<Loan> loans=new ArrayList<Loan>();
        loans.add(loan);
        customer.setLoans(loans);
        System.out.println("CustomerId"+customerDao.addCustomer(customer));
		*/
        for(Customer customer : customerDao.getAllCustomers())
        	System.out.println(customer.getCustomerId()+","+customer.getName()+","+customer.getMobileNo());
	  
        //delete customer
       // System.out.println(customerDao.deleteCustomer(8056050445L));
	  
        //update query
        
        System.out.println(customerDao.updateCustomer(2,"Balasubramaniam"));
	
	}

}
