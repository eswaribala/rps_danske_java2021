package com.danske.banking.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;

import com.danske.banking.models.Customer;

public class CustomerImpl implements CustomerDao{

	private EntityManagerFactory factory;
	private EntityManager entityManager;
	public CustomerImpl()
	{
		factory = Persistence.createEntityManagerFactory("loandb");	
		entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.getTransaction().commit();
			
	}
	
	@Override
	public long addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin();
		long customerId=0;
		try
		{
		//insert query	
		entityManager.persist(customer);
		entityManager.getTransaction().commit();
		customerId=customer.getCustomerId();
		}
		catch(HibernateException ex)
		{
			entityManager.getTransaction().rollback();
		}
		finally
		{
		entityManager.close();
		}
		return customerId;
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		entityManager=factory.createEntityManager();
		//select * from customer 
		//Query query = entityManager.createQuery("from Customer cust");	
		//return query.getResultList();
		
		TypedQuery<Customer> query =
				entityManager.createQuery("SELECT cust FROM Customer cust", Customer.class);
			  List<Customer> results = query.getResultList();
		return results;
	}

	@Override
	public int updateCustomer(long customerId,String name) {
		// TODO Auto-generated method stub
		entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin(); 
		int count=0;
		try
		{
		 Query query = entityManager.createQuery(
			      "UPDATE Customer SET name = :name WHERE customerId = :id");
	     query.setParameter("name",name);
	     query.setParameter("id", customerId);
	     count=query.executeUpdate();
	     entityManager.getTransaction().commit();
		}
		catch(HibernateException ex)
		{
			  entityManager.getTransaction().rollback();
		}
		finally
		{
			entityManager.close();
		}
		return count;
	}

	/*
	@Override
	public int deleteCustomer(long mobileNo) {
		// TODO Auto-generated method stub
		int deletedCount=0;
		entityManager=factory.createEntityManager();
		
		 TypedQuery<Customer> query = entityManager.createQuery(
			        "SELECT c FROM Customer c WHERE c.mobileNo = :mobileNo", Customer.class);
		 Customer customer=query.setParameter("mobileNo", mobileNo).getSingleResult();
		
		 System.out.println(customer.getLoans().get(0).getLoanNo());	
		 long loanNo=customer.getLoans().get(0).getLoanNo();
		 
		 try
		 {
			 entityManager.getTransaction().begin(); 
			 Query delQuery = entityManager.createQuery(
				      "DELETE FROM Loan l WHERE l.loanNo = :loanNo");
			 deletedCount = query.setParameter("loanNo", loanNo).executeUpdate();
			 entityManager.getTransaction().commit(); 
			 
		 }
		 catch(HibernateException ex)
		 {
			 entityManager.getTransaction().rollback(); 
			 
		 }
		 finally
		 {
			 entityManager.close();
		 }
		 
    return deletedCount;
	}
*/
}
