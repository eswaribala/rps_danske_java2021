package com.danske.banking.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.HibernateException;

import com.danske.banking.models.Customer;

public class CustomerImpl implements CustomerDao{

	private EntityManagerFactory factory;
	private EntityManager entityManager;
	public CustomerImpl()
	{
		factory = Persistence.createEntityManagerFactory("loandb");	
		entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.getTransaction().commit();
			
	}
	
	@Override
	public long addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin();
		long customerId=0;
		try
		{
		//insert query	
		entityManager.persist(customer);
		entityManager.getTransaction().commit();
		customerId=customer.getCustomerId();
		}
		catch(HibernateException ex)
		{
			entityManager.getTransaction().rollback();
		}
		finally
		{
		entityManager.close();
		}
		return customerId;
	}

}
