package com.danske.banking.dao;

import com.danske.banking.models.Customer;

public interface CustomerDao {
	
	long addCustomer(Customer customer);

}
