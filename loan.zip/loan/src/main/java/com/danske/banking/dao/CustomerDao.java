package com.danske.banking.dao;

import java.util.List;

import com.danske.banking.models.Customer;

public interface CustomerDao {
	
	long addCustomer(Customer customer);
    List<Customer> getAllCustomers();
    int updateCustomer(long customerId,String name);
    
	//int deleteCustomer(long mobileNo);
    
}
