package com.danske.loanapp.models;

import java.time.LocalDate;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "Customers")

public class Customer {
    @Id
  	private long customerKey;
   
	private String name;
  
   
	private LocalDate dob;
 
	private long mobileNo;

	public long getCustomerKey() {
		return customerKey;
	}

	public void setCustomerKey(long customerKey) {
		this.customerKey = customerKey;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
    
    
    
}
