package com.danske.loanapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.danske.loanapp.models.Customer;

import com.danske.loanapp.repositories.CustomerRepository;

@Service
public class CustomerService {
	
	//DI
	@Autowired
	private CustomerRepository customerRepository;

	//save
	public Customer addCustomer(Customer customer)
	{
		
		return customerRepository.save(customer);
		
	}
	
	//find all
	
	public List<Customer> getAllCustomers()
	{
		return customerRepository.findAll();
	}
	
	
	
	
	
}
