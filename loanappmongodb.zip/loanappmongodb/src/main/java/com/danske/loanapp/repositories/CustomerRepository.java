package com.danske.loanapp.repositories;


import org.springframework.data.mongodb.repository.MongoRepository;

import com.danske.loanapp.models.Customer;


public interface CustomerRepository extends MongoRepository<Customer,Long> {

}
