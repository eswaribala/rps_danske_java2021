package com.danske.banking.utility;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.danske.banking.dao.ReconcilationDao;
import com.danske.banking.dao.ReconcilationImpl;
import com.danske.banking.models.Transaction;
import com.danske.banking.models.TransactionType;

public class FileApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ReconcilationDao reconcilationDao=new ReconcilationImpl();
		
		System.out.println("File Status "+reconcilationDao.
				createFileObject("reports","TransactionReport.dat"));
		
		List<Transaction> transactions =new ArrayList<Transaction>();
		
		for(int i=0;i<1000;i++)
		{
			transactions.add(new Transaction(new Random().nextInt(100000),
					  new Random().nextInt(100000),
					LocalDate.now(),new Random().nextInt(10000),TransactionType.NB));			
		}
			
			
		  reconcilationDao.writeTransactionObject(transactions,
				  "reports","TransactionReport.dat");
	
	
	}

}
