package com.danske.banking.utility;

import com.danske.banking.dao.ReconcilationDao;
import com.danske.banking.dao.ReconcilationImpl;

public class FileApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ReconcilationDao reconcilationDao=new ReconcilationImpl();
		
		System.out.println("File Status "+reconcilationDao.createFile("reports","TransactionReport.csv"));
		
	}

}
