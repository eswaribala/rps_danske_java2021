package com.danske.banking.models;

public enum TransactionType {

	POS,IB,NB,WALLET,CHEQUE
}
