package com.danske.banking.utility;

import java.io.IOException;
import java.util.List;

import com.danske.banking.dao.ReconcilationImpl;
import com.danske.banking.models.Transaction;

public class FileReadingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Transaction> transactions;
		try {
			transactions = new ReconcilationImpl().
					readTransactionObject("reports", "TransactionReport.dat");
			transactions.stream().forEach(System.out::println);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}

}
