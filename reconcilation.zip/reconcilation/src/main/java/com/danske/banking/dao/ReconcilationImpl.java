package com.danske.banking.dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.danske.banking.models.Transaction;
import com.danske.banking.models.TransactionType;

public class ReconcilationImpl implements ReconcilationDao{
	@Override
	public boolean createFile(String path,String fileName) {
		// TODO Auto-generated method stub
		boolean status=false;
		File file=new File(path);
		if(file.exists())
			status=true;
		else
		{
			try {
				file.mkdir();
				file=new File(path,fileName);
				if(file.exists())
					status=true;
				else
				{
					file.createNewFile();
					BufferedWriter writer=new 
							BufferedWriter(new FileWriter(file,true));
					writer.write("Transaction Id,");
					writer.write("Account No,");
					writer.write("Amount,");
					writer.write("DOT,");
					writer.write("Type\n");
					writer.close();					
				    status=true;
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
				status=false;
			}		
		
		}	
		return status;
	}

	@Override
	public boolean writeTransaction(Transaction transaction, String path, String fileName) {
		// TODO Auto-generated method stub
		boolean status=false;
		try {
			BufferedWriter writer=new 
					BufferedWriter(new FileWriter(path+File.separator+fileName,true));
			writer.write(String.valueOf(transaction.getTransactionId())+",");
			writer.write(String.valueOf(transaction.getAccountNo())+",");
			writer.write(String.valueOf(transaction.getAmount())+",");
			writer.write(transaction.getDot().toString()+",");
			writer.write(transaction.getType().toString()+"\n");
			writer.close();
			status=true;
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return status;
	}

	@Override
	public List<Transaction> readTransaction(String path, String fileName) {
		// TODO Auto-generated method stub
		 List<Transaction> transactions=new ArrayList<Transaction>();
		try {
			BufferedReader reader=new BufferedReader(new FileReader(path+File.separator+fileName));
		    String line=null;
		    StringTokenizer tokenizer=null;
		    Transaction transaction=null;
		    int count=0;
			while((line=reader.readLine())!=null)
			{
				count++;
				if(count>1)
				{
				
				transaction=new Transaction();
				tokenizer=new StringTokenizer(line,",");	
				
				
				while(tokenizer.hasMoreElements())
				{
					transaction.setTransactionId(Long.parseLong(tokenizer.nextElement().toString()));
					transaction.setAccountNo(Long.parseLong(tokenizer.nextElement().toString()));					
					transaction.setAmount(Long.parseLong(tokenizer.nextElement().toString()));
					transaction.setDot(LocalDate.parse(tokenizer.nextElement().toString()));
					transaction.setType(TransactionType.valueOf(tokenizer.nextElement().toString()));
			     }
				
				transactions.add(transaction);		
				}
			}
		    reader.close();
		    
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return transactions;
	}

	@Override
	public boolean writeTransactionObject(List<Transaction> transactions, String path, String fileName) {
		// TODO Auto-generated method stub
		
		boolean status=false;
		
		try {
			ObjectOutputStream outStream=new ObjectOutputStream(
					new FileOutputStream(path+File.separator+fileName));
			for(Transaction transaction:transactions)
			   outStream.writeObject(transaction);
			status=true;
	        outStream.close(); 		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		return status;
	}

	@Override
	public List<Transaction> readTransactionObject(String path, String fileName) throws IOException {
		// TODO Auto-generated method stub
		
		List<Transaction> transactions=new ArrayList<Transaction>();
		ObjectInputStream in=null;
		Transaction transaction=null;
		try(FileInputStream fin=new FileInputStream(path+File.separator+fileName))
		{
			in=new ObjectInputStream(fin);
			while(true)
			{
				transaction=(Transaction) in.readObject();
				transactions.add(transaction);				
			}
		
			
		}
		catch(EOFException ex)
		{
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(in!=null)
				in.close();
		}
		
		
		
		
		return transactions;
	}

	@Override
	public boolean createFileObject(String path, String fileName) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				boolean status=false;
				File file=new File(path);
				if(file.exists())
					status=true;
				else
				{
					try {
						file.mkdir();
						file=new File(path,fileName);
						if(file.exists())
							status=true;
						else
						{
							file.createNewFile();											
						    status=true;
						}
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
						status=false;
					}		
				
				}	
				return status;
	}

}
