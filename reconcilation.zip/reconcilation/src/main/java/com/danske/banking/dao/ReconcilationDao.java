package com.danske.banking.dao;

public interface ReconcilationDao {

	boolean createFile(String path,String fileName);
}
