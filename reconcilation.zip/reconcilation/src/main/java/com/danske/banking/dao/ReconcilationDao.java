package com.danske.banking.dao;

import java.io.IOException;
import java.util.List;

import com.danske.banking.models.Transaction;

public interface ReconcilationDao {

	boolean createFile(String path,String fileName);
	boolean createFileObject(String path,String fileName);
	boolean writeTransaction(Transaction transaction, String path, String fileName);
	
	List<Transaction> readTransaction(String path, String fileName);
    boolean writeTransactionObject(List<Transaction> transactions, String path, String fileName);
	
	List<Transaction> readTransactionObject(String path, String fileName) throws IOException;
}
