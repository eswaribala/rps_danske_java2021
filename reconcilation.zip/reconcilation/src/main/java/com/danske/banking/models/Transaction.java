package com.danske.banking.models;

import java.io.Serializable;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Transaction implements Serializable{
	
	private long transactionId;
	private transient long accountNo;
	private LocalDate dot;
	private long amount;
	private TransactionType type;
	

}
