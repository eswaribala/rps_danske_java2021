package com.danske.banking.models;




public class Vehicle {

	
	
	public void getMessage(String regNo)
	{
		
		System.out.println("Registration Number"+regNo);
		new Bridge().getMessage(regNo);
		new TollBooth().getMessage(regNo);
	}
	
	
}
