package com.danske.banking.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.danske.banking.models.Vehicle;
import com.danske.banking.threads.VehicleThread;

public class ThreadSynchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<VehicleThread> vehicleThreads=new ArrayList<VehicleThread>();
		for(int i=0;i<5;i++)
		{
			vehicleThreads.add(new VehicleThread(new Vehicle(),
					"TN-02-AJ"+new Random().nextInt(10000)));
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
