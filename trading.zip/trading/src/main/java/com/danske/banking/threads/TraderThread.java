package com.danske.banking.threads;

public class TraderThread implements Runnable{

	
	@Override
	public void run() {
		// TODO Auto-generated method stub
	while(true)
	{
		System.out.println(Thread.currentThread().getName());
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			break;
		}
	}
		
		
	}

}
