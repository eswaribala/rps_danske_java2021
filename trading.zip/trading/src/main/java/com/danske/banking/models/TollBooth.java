package com.danske.banking.models;

public class TollBooth {

	public synchronized void getMessage(String regNo)
	{
		System.out.println("Crossing TollBooth Registration Number"+regNo);
	}
}
