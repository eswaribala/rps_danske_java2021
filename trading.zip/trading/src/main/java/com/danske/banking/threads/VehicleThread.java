package com.danske.banking.threads;

import com.danske.banking.models.Bridge;
import com.danske.banking.models.TollBooth;
import com.danske.banking.models.Vehicle;

public class VehicleThread implements Runnable{

	private Vehicle vehicle;
	private String regNo;
	public VehicleThread(Vehicle vehicle,String regNo)
	{
		this.regNo=regNo;
		this.vehicle=vehicle;
		new Thread(this,regNo).start();
		
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		synchronized(vehicle)
		{
			this.vehicle.getMessage(regNo);
			
			
		}
	}

}
