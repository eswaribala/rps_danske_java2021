package com.danske.banking.models;

public class Bridge {


	public synchronized void getMessage(String regNo)
	{
		System.out.println("Crossing Bridge Registration Number"+regNo);
	}
	
}
