package com.danske.banking.threads;

public class TradingThread extends Thread{

	private String name;
	public TradingThread(String name)
	{
		this.name=name;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		//changed the thread name
		Thread.currentThread().setName(name);
		for(char ch : name.toCharArray())
		{
			System.out.print(ch);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
	
}
