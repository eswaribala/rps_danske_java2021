package com.danske.banking.utility;

import java.util.Scanner;

import com.danske.banking.threads.TraderThread;
import com.danske.banking.threads.TradingThread;

public class TradingApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//main thread  
		//thread1
		System.out.println(Thread.currentThread().getPriority());

		//thread 2
		//user defined thread
		TradingThread tradingThread=new TradingThread("Trading-Thread");
		tradingThread.start();	
		//thread 3
		TraderThread traderThread=new TraderThread();
		Thread thread=new Thread(traderThread,"Trader-Thread");
		thread.start();
		System.out.println("Interrupt");
		String input=new Scanner(System.in).nextLine();
		if(input!=null)
			thread.interrupt();
		try {
			thread.join();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Main Waits.....");
		
	}

}
