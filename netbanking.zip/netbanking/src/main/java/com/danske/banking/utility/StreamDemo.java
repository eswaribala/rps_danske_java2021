package com.danske.banking.utility;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import com.danske.banking.dao.CustomerImpl;
import com.danske.banking.dao.DeveloperImpl;
import com.danske.banking.models.Customer;
import com.danske.banking.models.Developer;

public class StreamDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Customer> customers=new CustomerImpl().getCustomers();
		//all the customers
		System.out.println("All Customers");
		customers.stream().forEach(System.out::println);		
		//filter the customers based on dob
		System.out.println("Filter by DOB");
		customers.stream().filter(c->c.getDob().getYear()>1990)
		.forEach(System.out::println);		
		//filter the customers based on dob, print only the name
		System.out.println("Filter by DOB and Print Only Name");
		customers.stream().filter(c->c.getDob().getYear()>1990)
		.map(c->c.getName())
		.forEach(System.out::println);		
		//collect filtered data as names and don't print		
		List<String> customerNames=customers.stream().filter(c->c.getDob().getYear()>1990)
		.map(c->c.getName()).collect(Collectors.toList());		
		//array of branch names
		String[] branchNames= {"Adyar","Velachery","Anna Nagar","ICF"};
		Arrays.asList(branchNames).stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
	
		//print customer names in alphabetic order after filtering them by dob
		System.out.println("Filter by DOB, Sort by Name and Print Only Name");
		customers.stream().filter(c->c.getDob().getYear()>1980)
		.sorted((c1,c2)->c1.getName().compareTo(c2.getName()))
		.map(c->c.getName()).forEach(System.out::println);
		
		//reducer --- aggregator
		int[] array = {23,43,56,97,32};
		System.out.println("Reduce to Sum");
		//reduce to sum
	  	  Arrays.stream(array).reduce(Integer::sum).
	  	  ifPresent(s -> System.out.println(s/array.length));	  
		//compute the average age of a customer using lambda
	  List<Long> ages=customers.stream()
			  .map(c->ChronoUnit.YEARS.between(c.getDob(),LocalDate.now()))
			  .collect(Collectors.toList()); 
	  	
	 System.out.println(ages.stream().mapToLong((x) -> x)
      .summaryStatistics());  
	 
	 //search operation with any match
	 
	 System.out.println("Customer Search Any Match"+customers.stream()
	 .anyMatch(c->c.getName().contains("0")));
	 
	 System.out.println("Customer Search All Match"+customers.stream()
	 .allMatch(c->c.getName().contains("0")));
	 
	 Optional<Customer> customer = customers.stream()
			 .filter(c->c.getDob().getYear()>1990)
			 .findFirst();
	 System.out.println("Customer Available"+customer.isPresent());
	 if(customer.isPresent())
		 System.out.println(customer);
	 
	 //parallelism test
	 ForkJoinPool commonPool = ForkJoinPool.commonPool();
	 System.out.println("Parallel"+commonPool.getParallelism());  
	 
	 //parallel task
	 /*
	 int size=10000000;
	 List<UUID> ids=new ArrayList<UUID>(size);
	 for(int i=0;i<size;i++)
	 {
		 ids.add(UUID.randomUUID());
	 }
	 */
	 /*
	 System.out.println("Before Sorting.....");
	 long t0=System.nanoTime();
	 System.out.println("Nano Time....."+t0);
	 ids.stream().sorted().count();
	 System.out.println("After Sorting.....");
	 long t1=System.nanoTime();
	 System.out.println("Nano Time....."+t1);
	 System.out.println("Time Taken to sort"+TimeUnit.NANOSECONDS.toMillis(t1 - t0));
	 */
	 /*
	 System.out.println("Before Parallel Sorting.....");
	 long t0=System.nanoTime();
	 System.out.println("Nano Time....."+t0);
	 ids.parallelStream().sorted().count();
	 System.out.println("After Parallel Sorting.....");
	 long t1=System.nanoTime();
	 System.out.println("Nano Time....."+t1);
	 System.out.println("Time Taken to parallel sort"+TimeUnit.NANOSECONDS.toMillis(t1 - t0));
	 */
	List<Developer>	developers=new DeveloperImpl().getDevelopers();
	 
	developers.stream().map(d->d.getLanguages())
	.flatMap(l->l.stream())
	.distinct()
	.forEach(System.out::print);
	 System.out.println("\n");
	List<String> languages =developers.stream().map(d->d.getLanguages())
	.flatMap(l->l.stream()).collect(Collectors.toList());
	
	languages.removeIf(l->l.equals("Java"));
	for(String lang:languages)
		System.out.print(lang+",");
	
	 
	}

}
