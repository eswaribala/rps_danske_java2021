package com.danske.banking.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.danske.banking.models.Customer;

public class CustomerImpl implements CustomerDao{

	@Override
	public List<Customer> getCustomers() {
		// TODO Auto-generated method stub
		return createCustomers();
	}

	
	private List<Customer> createCustomers()
	{
		List<Customer> customers=new ArrayList<Customer>();
		
		Customer customer=null;
		for(int i=0;i<5;i++)
		{
			customer=new Customer(483658+i,"customer"+i,
					LocalDate.of(1970+new Random().nextInt(30),1+new Random().nextInt(11),
							1+new Random().nextInt(26)), 
					8999988888L+new Random().nextInt(10000000));
			customers.add(customer);
			
		}
		return customers;
	}
	
}
