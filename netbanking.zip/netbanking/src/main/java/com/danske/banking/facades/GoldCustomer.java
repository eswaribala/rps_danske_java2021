package com.danske.banking.facades;

public class GoldCustomer implements BankCustomer {

	@Override
	public String notification() {
		// TODO Auto-generated method stub
		return "You have been upgraded to Gold Customer!!!";
	}

	
}
