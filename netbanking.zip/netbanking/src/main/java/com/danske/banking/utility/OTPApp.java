package com.danske.banking.utility;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.util.List;
import java.util.Random;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import com.danske.banking.dao.CustomerDao;
import com.danske.banking.dao.CustomerImpl;
import com.danske.banking.facades.OTP;
import com.danske.banking.models.Customer;

public class OTPApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    //lambda expression overriding generate otp
	 //OTP otp=()->1000+new Random().nextInt(100);
	 
	//Existing functional interface
		
	Function<Integer,Long> otp=	(data)->1000L+LocalDate.now().getDayOfYear()+
			LocalTime.now().getSecond()+data;
		
	 System.out.println(otp.apply(999));	 
	 
	 //compute age	 
      
	 BiFunction<LocalDate,LocalDate,Period> computeAge=(p1,p2)->(Period.between(p1, p2));
	 
	 System.out.println(computeAge.apply(LocalDate.now(),
			 new CustomerImpl().getCustomers().get(0).getDob()));
	 
	 //Consumer accepts the data and returns nothing
	 
	 Consumer<Integer> showCustomers=(id)->{
		
		 for(Customer customer : new CustomerImpl().getCustomers())
		 {
			 if(customer.getCustomerId()==id)
			     System.out.println(customer);
		 }
	 };
	 
	 showCustomers.accept(483660);
	 
	//Supplier
	 Supplier<String> notification=CustomerDao::sendNotification;
	 System.out.println(notification.get());
	 
	 
	}

}
