package com.danske.banking.facades;

@FunctionalInterface
public interface OTP {

	long generateOTP();
}
