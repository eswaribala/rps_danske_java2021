package com.danske.banking.utility;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.danske.banking.bl.CustomerSorter;
import com.danske.banking.dao.CustomerDao;
import com.danske.banking.dao.CustomerImpl;
import com.danske.banking.facades.GoldCustomer;
import com.danske.banking.models.Customer;

public class BankingApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CustomerDao customerDao=new CustomerImpl();
		
		List<Customer> customers=customerDao.getCustomers();
		
		System.out.println("Before Sorting.....");
		for(Customer customer:customers)
		{
			System.out.println(customer);
		}
		
		//sort the customers by dob
		System.out.println("After Sorting.....");
		
		//without lambda expression, sort it		
		
		/*
		Collections.sort(customers, new CustomerSorter());
		
		for(Customer customer:customers)
		{
			System.out.println(customer);
		}
		*/
		//with lambda
		
		//sort the customers by dob
	    System.out.println("After Sorting by Lambda.....");
        customers.sort((Customer c1, Customer c2)->{
			return c1.getDob().compareTo(c2.getDob());
		});
		for(Customer customer:customers)
		{
			System.out.println(customer);
		}
		
		
		GoldCustomer bankCustomer=new GoldCustomer();
		
		System.out.println(bankCustomer.notification());
		
		
	}

}
