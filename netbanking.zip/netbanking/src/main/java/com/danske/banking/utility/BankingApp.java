package com.danske.banking.utility;
import com.danske.banking.dao.CustomerDao;
import com.danske.banking.dao.CustomerImpl;
import com.danske.banking.models.Customer;

public class BankingApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CustomerDao customerDao=new CustomerImpl();
		
		for(Customer customer:customerDao.getCustomers())
		{
			System.out.println(customer);
		}
		
	}

}
