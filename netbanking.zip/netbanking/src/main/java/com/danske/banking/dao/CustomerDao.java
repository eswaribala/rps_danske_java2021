package com.danske.banking.dao;

import java.time.LocalDate;
import java.util.List;

import com.danske.banking.models.Customer;

public interface CustomerDao {
	//abstract method
	List<Customer> getCustomers();//will not have implementation
	//default method
	
	//static method
	
	static String sendNotification()
	{
		if(LocalDate.now().getDayOfMonth()==1)
			return "Bank Statement Generated";
		else
			return "Nothing to send";
		
	}
	
	

}
