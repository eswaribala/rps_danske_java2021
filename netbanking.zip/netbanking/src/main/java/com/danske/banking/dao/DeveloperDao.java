package com.danske.banking.dao;

import java.util.List;

import com.danske.banking.models.Developer;

public interface DeveloperDao {

	List<Developer> getDevelopers();
}
