package com.danske.banking.facades;

public interface BankCustomer {

	default String notification()
	{
		return "Welcome to Danske!!!";
	}
}
